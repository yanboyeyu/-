﻿using UnityEngine;
using System.Collections;

public class Damper : MonoBehaviour {

    public float speed = 120;

    private bool isRotate = false;
    private float angle = 0;

	// Update is called once per frame
	void Update () {
        if (isRotate) {
            angle += speed * Time.deltaTime;
            transform.Rotate(Vector3.forward * speed * Time.deltaTime);
            if (angle > 135) {
                isRotate = false;
            }
        }
	}

    public void StartRotate() {
        isRotate = true;
    }
}
