﻿using UnityEngine;
using System.Collections;

public class Car : MonoBehaviour {

    public Vector3 targetPos;
    public Vector3 endTargetPos;
    public int smoothing = 2;
    public Wheel[] wheelArray;
    public Damper damper;

    private bool isReaching = false;//表示是否达到目标位置

    void Start() {
        Invoke("PlaySound", 0.3f);
    }

	// Update is called once per frame
	void Update () {
        transform.position = Vector3.Lerp(transform.position, targetPos, smoothing * Time.deltaTime);
        if (isReaching == false) {
            if (Vector3.Distance(transform.position, targetPos) < 0.4f) {
                isReaching = true;
                OnReach();//达到目标位置之后，进行的操作
            }
        }
	}

    void PlaySound() {
        audio.Play();
    }

    void OnReach() {
        foreach (Wheel w in wheelArray) {
            w.Stop();
        }
        damper.StartRotate();
        //放下主角 TODO
        //把车子开走
        Invoke("GoOut", 1f);
    }
    void GoOut() {
        targetPos = endTargetPos;
        foreach (Wheel w in wheelArray) {
            w.Start();
        }
        Destroy(this.gameObject, 1f);
    }
}
