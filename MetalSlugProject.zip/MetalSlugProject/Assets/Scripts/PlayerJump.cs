﻿using UnityEngine;
using System.Collections;


public class PlayerJump : MonoBehaviour {

    public float animSpeed = 10;//1秒播放10帧图片
    private float animTimeInterval = 0;
    public AnimStatus status = AnimStatus.Idle;//表示主角当前的状态

    public SpriteRenderer upRenderer;//上半身的渲染器
    public SpriteRenderer downRenderer;//下半身的渲染器

    public Sprite[] idleUpSpriteArray;
    private int idleUpIndex = 0;
    private int idleUpLength = 0;
    private float idleUpTimer = 0;


    public Sprite[] idleDownSpriteArray;
    private int idleDownIndex = 0;
    private int idleDownLength = 0;
    private float idleDownTimer = 0;

    public Sprite shootUpSprite;
    public Sprite shootHorizontalSprite;

    private bool shoot = false;
    private ShootDir shootDir;

    public GameObject projectilePrefab;
    public Transform shootupPos;
    public Transform shoothorizontalPos;

    // Use this for initialization
    void Start() {
        animTimeInterval = 1 / animSpeed;//得到每一帧的时间间隔
        idleUpLength = idleUpSpriteArray.Length;
        idleDownLength = idleDownSpriteArray.Length;
    }

    // Update is called once per frame
    void Update() {
        switch (status) {
            case AnimStatus.Idle:
                idleUpTimer += Time.deltaTime;
                if (idleUpTimer > animTimeInterval) {//播放下一帧
                    idleUpTimer -= animTimeInterval;//当计时器减去一个周期的时间
                    idleUpIndex++;//当帧数自增（播放下一帧）
                    idleUpIndex %= idleUpLength;//(判断是否到达最大帧数)
                    upRenderer.sprite = idleUpSpriteArray[idleUpIndex];
                }
                idleDownTimer += Time.deltaTime;
                if (idleDownTimer > animTimeInterval) {//播放下一帧
                    idleDownTimer -= animTimeInterval;//当计时器减去一个周期的时间
                    idleDownIndex++;//当帧数自增（播放下一帧）
                    idleDownIndex %= idleDownLength;//(判断是否到达最大帧数)
                    downRenderer.sprite = idleDownSpriteArray[idleDownIndex];
                }

                break;
            
        }
    }

    void LateUpdate() {
        if (shoot) {
            shoot = false;
            //进行射击
            Vector3 pos = Vector3.zero;
            if(shootDir==ShootDir.Top){
                pos = shootupPos.position;
            }else if(shootDir==ShootDir.Left||shootDir==ShootDir.Right){
                pos = shoothorizontalPos.position;
            }
            int z_rotation=0;
            switch (shootDir)
	        {
		        case ShootDir.Left:
                    upRenderer.sprite = shootHorizontalSprite;
                    z_rotation=180;
                break;
                case ShootDir.Right:
                upRenderer.sprite = shootHorizontalSprite;
                    z_rotation=0;
                 break;
                case ShootDir.Top:
                 upRenderer.sprite = shootUpSprite;
                    z_rotation=90;
                 break;
                case ShootDir.Down:
                    z_rotation=270;
                 break;
                default:
                 break;
	        }
            GameObject.Instantiate(projectilePrefab, pos, Quaternion.Euler(0, 0, z_rotation));

        }
    }

    public void Shoot(float v_h, bool isTopKeyDown, bool isBottomKeyDown) {
        shoot = true;

        //得到射击的方向
        if (isTopKeyDown == false && isBottomKeyDown == false) {
            if (transform.localScale.x == 1) {
                shootDir = ShootDir.Left;
            } else if (transform.localScale.x == -1) {
                shootDir = ShootDir.Right;
            }
        } else {
            if (isTopKeyDown) {
                shootDir = ShootDir.Top;
            } else if (isBottomKeyDown) {
                shootDir = ShootDir.Down;
            }
        }
    }
}
